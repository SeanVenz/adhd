<?php
/**
 * Template Name: Assessment
 */
get_header();

?>

<style>
    .quiz.has-results {
        background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/home/Test_assesstment_BG.webp') !important;
    }
</style>

<section class="quiz">
    <div class="header-holder">
        <a href="<?php echo get_home_url(); ?>"> <span>Dom</span> <svg xmlns="http://www.w3.org/2000/svg" width="24"
                height="24" fill="#17462B" class="bi bi-house-fill" viewBox="0 0 16 16">
                <path
                    d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293z" />
                <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293z" />
            </svg></a>
    </div>
    <div class="min-width">

        <div class="quiz-holder">

            <div class="short-code">

                <?php echo do_shortcode('[qsm quiz=1]'); ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>

<?php wp_reset_postdata(); ?>

<script>
document.addEventListener('DOMContentLoaded', function () {

    // Define the function
    function checkAndUpdateQuiz() {
        document.querySelectorAll('.quiz').forEach(function (quizDiv) {
            if (quizDiv.querySelector('.qmn_results_page')) {
                quizDiv.classList.add('has-results');
            }
        });
    }

    // Run the check initially
    checkAndUpdateQuiz();

    // Set up a MutationObserver to detect dynamic changes
    const observer = new MutationObserver(function (mutations) {
        let needsCheck = false;

        mutations.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                needsCheck = true;
            }
        });

        if (needsCheck) {
            setTimeout(checkAndUpdateQuiz, 100); // Small delay to ensure DOM updates
        }
    });

    // Observe quiz containers for changes
    const quizContainers = document.querySelectorAll('.quiz-holder, .short-code');
    quizContainers.forEach(container => {
        observer.observe(container, { childList: true, subtree: true });
    });

    // Also observe body as fallback
    observer.observe(document.body, { childList: true, subtree: true });

    // jQuery event listener for clicking on answers
    jQuery(document).ready(function ($) {

        $(document).on("click", ".qmn_mc_answer_wrap", function (e) {

            var radioInput = $(this).find('input[type="radio"]');
            if (radioInput.length) {

                radioInput.prop("checked", true).trigger("change").focus();
            } else {
            }
        });
    });

    function updatePageIndicator() {
        let pageIndicator = document.querySelector(".pages_count"); // Adjust class if needed
        if (pageIndicator) {
            let text = pageIndicator.innerText.trim(); // Get current text
            let match = text.match(/(\d+)\s*out\s*of\s*(\d+)/i); // Match "X out of Y"

            if (match) {
                let currentPage = match[1];
                let totalPages = match[2];
                pageIndicator.innerText = `${currentPage} of ${totalPages}`; // Change format dynamically
            }
        }
    }

    // Run immediately on page load
    updatePageIndicator();

    // Observe changes in the pageIndicator element
    let targetNode = document.querySelector(".pages_count");
    if (targetNode) {
        let observer = new MutationObserver(updatePageIndicator);
        observer.observe(targetNode, { childList: true, subtree: true, characterData: true });
    }
});

</script>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const el = document.querySelector('.pages_count');
    if (el) {
      el.textContent = el.textContent.replace(/\bof\b/, 'z');
    }
  });
</script>

<script>
function updateNextButtonState() {
  const currentPage = document.querySelector(".qsm-page:not([style*='display: none'])");
  if (!currentPage) {
    console.log("No visible .qsm-page found.");
    return;
  }

  // Get the correct radio buttons for the current page
  const options = currentPage.querySelectorAll("input[type='radio'].qmn_quiz_radio");
  const nextBtn = document.querySelector("a.mlw_custom_next");

  if (!nextBtn) {
    console.log("❌ Next button not found.");
    return;
  }

  console.log("✅ Next button found!");

  // Function to check if any radio option is selected
  const checkSelection = () => {
    // Check if any radio button is selected
    const anySelected = Array.from(options).some(option => option.checked);
    
    console.log("Radio buttons found:", options.length);
    console.log("Any selected:", anySelected);
    
    if (anySelected) {
      nextBtn.classList.remove("qsm-disabled");
      nextBtn.style.pointerEvents = "auto";
      console.log("✔ Option selected — Next enabled");
    } else {
      nextBtn.classList.add("qsm-disabled");
      nextBtn.style.pointerEvents = "none";
      console.log("❌ No option selected — Next disabled");
    }
  };

  // Disable next button initially
  nextBtn.classList.add("qsm-disabled");
  nextBtn.style.pointerEvents = "none";

  // Add event listeners to each radio option
  options.forEach(option => {
    const parent = option.parentNode;
    const newOption = option.cloneNode(true);
    parent.replaceChild(newOption, option);
  });

  // Add fresh event listeners - with the 'once' option to remove them after being triggered
  currentPage.querySelectorAll("input[type='radio'].qmn_quiz_radio").forEach(option => {
    option.addEventListener("change", () => {
      checkSelection();
    }, { once: true });  // Ensure the event listener triggers only once

    // Also add click handlers to the labels for better coverage
    const id = option.id;
    if (id) {
      const label = currentPage.querySelector(`label[for="${id}"]`);
      if (label) {
        label.addEventListener("click", () => {
          setTimeout(checkSelection, 50); // Small delay to ensure radio state updates
        }, { once: true }); // Ensure it triggers only once
      }
    }

    // Add click handler to parent wrapper (for any user click)
    const wrapper = option.closest('.qmn_mc_answer_wrap');
    if (wrapper) {
      wrapper.addEventListener("click", () => {
        setTimeout(checkSelection, 50); // Delay to ensure the radio button state is updated
      }, { once: true });
    }
  });

  // Initial check
  checkSelection();
}

// Wait for everything to be fully loaded
window.addEventListener("load", function() {
  // Initial setup with a delay
  setTimeout(updateNextButtonState, 300);

  // Observer for when QSM loads new pages/questions
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        // We need a delay here too
        setTimeout(updateNextButtonState, 100);
        break;
      }
    }
  });

  // Observe the whole document for QSM's dynamic changes
  observer.observe(document.body, { 
    childList: true, 
    subtree: true 
  });
});
</script>
